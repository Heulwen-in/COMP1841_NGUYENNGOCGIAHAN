<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}

try {
    // Connect to the database using PDO
    $dsn = "mysql:host=localhost;dbname=heulwen;charset=utf8mb4";
    $username = "root";
    $password = "";

    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch all modules
    $stmt = $pdo->query("SELECT id, name FROM modules");
    $modules = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kingdom Come | Manage Modules</title>
    <link rel="stylesheet" href="css/manage_m0dules.css">
</head>
<body>
    <div class="background">
        <div class="container">
            <h1>Manage Modules</h1>
            <a href="add_module.php" class="add">Add New Module</a>

            <?php foreach ($modules as $module): ?>
                <h2><?= htmlspecialchars($module['name']); ?></h2>
                <a href="edit_module.php?module_id=<?= $module['id']; ?>" class="edit">Edit</a>
                <a href="delete_module.php?module_id=<?= $module['id']; ?>" class="delete"
                   onclick="return confirm('Are you sure you want to delete this module?');">Delete</a>
            <?php endforeach; ?>

            <br><br><br><br>
            <a href="admin_dashboard.php" class="back-home">Back to Admin Dashboard</a>
        </div>
    </div>
</body>
</html>
