<?php
session_start();
require 'dbConnect.php';

if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit();
}
$user = $_SESSION['user'];

try {
    $stmtModules = $pdo->query("SELECT id, name FROM modules"); 
    $modules = $stmtModules->fetchAll(PDO::FETCH_ASSOC);

    $stmtPosts = $pdo->query("
        SELECT posts.id, posts.title, posts.created_at, posts.updated_at, posts.user_id, posts.module_id, users.name AS username 
        FROM posts 
        JOIN users ON posts.user_id = users.id 
        ORDER BY posts.created_at DESC
    ");
    $posts = $stmtPosts->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kingdom Come | Home</title>
    <link rel="stylesheet" href="css/h0me.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const moduleSelect = document.querySelector('.module-select');
            const postList = document.querySelector('.post-list');
            const posts = <?php echo json_encode($posts); ?>;

            moduleSelect.addEventListener('change', () => {
                const moduleId = moduleSelect.value;
                if (moduleId === 'all') {
                    displayPosts(posts); 
                } else {
                    const filteredPosts = posts.filter(post => post.module_id == moduleId);
                    displayPosts(filteredPosts);
                }
            });

            const currentUserId = <?php echo json_encode($user['id']); ?>;

            function displayPosts(postData) {
                postList.innerHTML = '';
                if (postData.length === 0) {
                    postList.innerHTML = '<p>No posts found.</p>';
                    return;
                }
                postData.forEach(post => {
                    const postItem = document.createElement('div');
                    postItem.classList.add('post');
                    postItem.id = `post-${post.id}`;
                    postItem.innerHTML = `
                        <h3><a href="view_post.php?post_id=${post.id}">${post.title}</a></h3>
                        <p><b>Posted by:</b> ${post.username}</p>
                        <p><b>Posted on:</b> ${new Date(post.created_at).toLocaleString()}</p>
                        ${post.updated_at ? `<p><b>Updated on:</b> ${new Date(post.updated_at).toLocaleString()}</p>` : ''}
                        ${currentUserId == post.user_id ? `
                            <a href="user_editpost.php?post_id=${post.id}" class="post-button">Edit</a>
                            <a href="delete_post.php?post_id=${post.id}" class="post-button" onclick="return confirm('Are you sure you want to delete this post?');">Delete</a>
                        ` : ''}
                    `;
                    postList.appendChild(postItem);
                });
            }

            displayPosts(posts); 
        });
    </script>
</head>

<body>
<div class="background">


    <!-- Navigation Buttons -->
    <div class="container">
        <a href="create_post.php" class="home-button">Create Post</a>
        <a href="edit_profile.php" class="home-button">Edit Profile</a>
        <a href="contactadmin.php" class="home-button" target="_blank">Contact Admin</a>
        <a href="logout.php" class="home-button">Log Out</a>
    </div>

    <!-- Welcome Section -->
    <div class="home_container">
        <div class="welcome">
            <h1>Welcome to Kingdom Come, <?php echo htmlspecialchars($user['name']); ?>!</h1>
            <p><b>Username:</b> <?php echo htmlspecialchars($user['name']); ?> <i class="fas fa-cloud"></i></p>
            <p><b>Email:</b> <?php echo htmlspecialchars($user['email']); ?></p>
        </div>
        <div class="search-container">
        <label for="module-select">Filter:</label>
        <select class="module-select" id="module-select">
            <option value="all">All Modules</option>
            <?php foreach ($modules as $module): ?>
                <option value="<?php echo $module['id']; ?>">
                    <?php echo htmlspecialchars($module['name']); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
        <!-- Post List Section -->
        <div class="post-list">
        <h3>All Posts</h3>
            <?php foreach ($posts as $post): ?>
                <div class="post" id="post-<?php echo $post['id']; ?>">
                    <h3><a href="view_post.php?post_id=<?php echo $post['id']; ?>">
                        <?php echo htmlspecialchars($post['title']); ?>
                    </a></h3>
                    <p><b>Posted by:</b> <?php echo htmlspecialchars($post['username']); ?></p>
                    <p><b>Posted on:</b> <?php echo date("d/m/Y  H:i", strtotime($post['created_at'])); ?></p>
                    <?php if (!empty($post['updated_at'])): ?>
                        <p><b>Updated on:</b> <?php echo date("d/m/Y H:i", strtotime($post['updated_at'])); ?></p>
                    <?php endif; ?>
                    <?php if ($user['id'] == $post['user_id']): ?>
                        <a href="user_editpost.php?post_id=<?php echo $post['id']; ?>" class="post-button">Edit</a>
                        <a href="delete_post.php?post_id=<?php echo $post['id']; ?>" class="post-button" onclick="return confirm('Are you sure you want to delete this post?');">Delete</a>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
</body>
</html>
