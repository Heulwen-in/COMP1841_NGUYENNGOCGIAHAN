<?php
session_start();

if (isset($_GET['post_id']) && !empty($_GET['post_id'])) {
    $postId = intval($_GET['post_id']); 
    $userId = $_SESSION['user_id'] ?? null;

    try {
        $dsn = "mysql:host=localhost;dbname=heulwen;charset=utf8mb4";
        $username = "root";
        $password = "";
        $pdo = new PDO($dsn, $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $stmt = $pdo->prepare("SELECT user_id FROM posts WHERE id = ?");
        $stmt->execute([$postId]);
        $post = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($post) {
            if ($post['user_id'] == $userId) {
                $stmtDelete = $pdo->prepare("DELETE FROM posts WHERE id = ?");
                $stmtDelete->execute([$postId]);

                header("Location: home.php");
                exit();
            } 
            elseif (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
                $stmtDelete = $pdo->prepare("DELETE FROM posts WHERE id = ?");
                $stmtDelete->execute([$postId]);

                header("Location: manage_posts.php");
                exit();
                
            } else {
                header("Location: manage_posts.php");
                exit();
            }
        } else {
            header("Location: manage_posts.php");
            exit();
        }
    } catch (PDOException $e) {
        header("Location: manage_posts.php");
        exit();
    }
} else {
    header("Location: manage_posts.php");
    exit();
}
