<?php
session_start();
require 'dbConnect.php'; // Ensure you have a database connection

// Fetch the modules from the database
try {
    $stmt = $pdo->query("SELECT id, name FROM modules");
    $modules = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/create_p0st.css">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap" rel="stylesheet">
    <title>Kingdom Come | Create New Question</title>
</head>
<body>
<div class="background">
  
    <div class="question_container">
        <h1>Post a Question</h1>
        <form action="create_post_action.php" method="POST" enctype="multipart/form-data">
            <label for="title">Title: </label>
            <input type="text-post" name="title" id="title" required>
            
            <label for="content">Content: </label>
            <textarea name="content" id="content" required></textarea>  

            <label for="module_id">Select module: </label>
            <select name="module_id" id="module_id" required="">
            <?php foreach ($modules as $module): ?>
                <option value="<?= htmlspecialchars($module['id']) ?>"><?= htmlspecialchars($module['name']) ?></option>
            <?php endforeach; ?>
            </select>
            
            <label for="image">Upload Image:</label> 
            <input type="file" name="image" id="image">
            <button type="submit">Post</button>
        </form>
        <a href="home.php" class="back-link">Back to Home</a>
    </div>
</body>
</html>
