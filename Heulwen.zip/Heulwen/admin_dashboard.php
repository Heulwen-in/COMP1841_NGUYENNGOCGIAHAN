<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kingdom Come | Admin Dashboard</title>
    <link rel="stylesheet" href="css/admin_dashb0ard.css">
    
</head>
<body>
    <div class= "background">
        <div class="admin_dashboard">
            <h1>Admin Dashboard</h1>
            <h2>Manage Site Content</h2>
            <a href="manage_posts.php" class="home-button">Manage Posts</a>
            <a href="manage_users.php" class="home-button">Manage Users</a>
            <a href="manage_modules.php" class="home-button">Manage Modules</a>
            <a href="logout.php" class="home-button">Logout</a>
        </div>
</div>
</body>
</html>
