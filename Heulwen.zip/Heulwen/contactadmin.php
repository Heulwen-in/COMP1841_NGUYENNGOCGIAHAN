<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . "/vendor/autoload.php";

$responses = [];

// Define the admin email address
$admin_email = 'hannnggcs230054@fpt.edu.vn'; // Change this to the actual admin email

if (isset($_POST['email'], $_POST['subject'], $_POST['name'], $_POST['msg'])) {
    if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        $responses[] = 'Email is not valid!';
    }
    if (empty($_POST['email']) || empty($_POST['subject']) || empty($_POST['name']) || empty($_POST['msg'])) {
        $responses[] = 'Please complete all fields!';
    } 

    if (!$responses) {
        $mail = new PHPMailer(true);
        try {
            //Server settings
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com'; // Set the SMTP server to send through
            $mail->SMTPAuth = true; // Enable SMTP authentication
            $mail->Username = 'hannnggcs230054@fpt.edu.vn'; // Your SMTP username (Gmail address)
            $mail->Password = 'hhik dmml cpzt ulxg'; // Your SMTP password (Gmail password or App Password)
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Enable TLS encryption
            $mail->Port = 587; // TCP port to connect to

            //Recipients
            $mail->setFrom('your_email@gmail.com', 'Mailer'); // Your email and name
            $mail->addAddress($admin_email); // Add a recipient
            $mail->addReplyTo($_POST['email'], $_POST['name']); // Add a reply-to address

            // Content
            $mail->isHTML(false); // Set email format to plain text
            $mail->Subject = $_POST['subject'];
            $mail->Body    = "From: " . $_POST['name'] . " <" . $_POST['email'] . ">\n\n" . $_POST['msg'];

            $mail->send();
            $responses[] = 'Message sent!';
        } catch (Exception $e) {
            $responses[] = "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,minimum-scale=1">
		<title>Contact Form</title>
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
		<link rel="stylesheet" href="css/contact.css">
	</head>
	<body>
        <div class = "background">
            <div class = "contact">
		        <form method="post" action="">
			        <h1>Contact Form</h1>
			        <div class="fields">
				        <label for="email">
					        <i class="fas fa-envelope"></i>
					        <input id="email" type="email" name="email" placeholder="Your Email" required>
				        </label>
				        <label for="name">
					        <i class="fas fa-user"></i>
					        <input type="text" name="name" placeholder="Your Name" required>
                        </label>
				        <input type="text" name="subject" placeholder="Tittle" required>
				        <textarea name="msg" placeholder="Message" required></textarea>
                        <?php if ($responses): ?>
                        <p class="responses"><?php echo implode('<br>', $responses); ?></p>
                        <?php endif; ?>
			            <input type="submit">
                    </div>
		        </form>
                <a href="home.php" class="back-link">Back to home</a>
            </div>
        </div>
	</body>
</html>