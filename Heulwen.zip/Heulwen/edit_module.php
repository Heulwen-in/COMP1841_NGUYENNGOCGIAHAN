<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}

if (isset($_GET['module_id'])) {
    $module_id = $_GET['module_id'];

    try {
        // Connect to the database using PDO
        $dsn = "mysql:host=localhost;dbname=heulwen;charset=utf8mb4";
        $username = "root";
        $password = "";

        $pdo = new PDO($dsn, $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Fetch the module to be edited
        $stmt = $pdo->prepare("SELECT id, name FROM modules WHERE id = :id");
        $stmt->bindParam(':id', $module_id, PDO::PARAM_INT);
        $stmt->execute();
        $module = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$module) {
            die("Module not found.");
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Process form submission
            $new_name = trim($_POST['name']);
            if (!empty($new_name)) {
                // Update the module name
                $updateStmt = $pdo->prepare("UPDATE modules SET name = :name WHERE id = :id");
                $updateStmt->bindParam(':name', $new_name, PDO::PARAM_STR);
                $updateStmt->bindParam(':id', $module_id, PDO::PARAM_INT);
                $updateStmt->execute();

                header("Location: manage_modules.php"); // Redirect back to manage modules page
                exit();
            } else {
                $error = "Module name cannot be empty.";
            }
        }
    } catch (PDOException $e) {
        die("Database error: " . $e->getMessage());
    }
} else {
    header("Location: manage_modules.php"); // Redirect if no module ID is provided
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Module</title>
    <link rel="stylesheet" href="css/manage_m0dules.css">
</head>
<body>
    <div class="background">
        <div class="container">
            <h1>Edit Module</h1>

            <?php if (isset($error)): ?>
                <div class="error"><?= htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <form action="edit_module.php?module_id=<?= $module['id']; ?>" method="POST">
                <label for="name">Module Name:</label>
                <input type="text" id="name" name="name" value="<?= htmlspecialchars($module['name']); ?>" required>
                <button type="submit">Save Changes</button>
            </form>

            <a href="manage_modules.php" class="back-home">Back to Manage Modules</a>
        </div>
    </div>
</body>
</html>