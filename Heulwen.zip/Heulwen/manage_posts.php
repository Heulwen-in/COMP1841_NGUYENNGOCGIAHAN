<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}

try {
    // Connect to the database using PDO
    $dsn = "mysql:host=localhost;dbname=heulwen;charset=utf8mb4";
    $username = "root";
    $password = "";

    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmtModules = $pdo->query("SELECT id, name FROM modules");
    $modules = $stmtModules->fetchAll(PDO::FETCH_ASSOC);

    $stmtUsers = $pdo->query("SELECT id, name FROM users");
    $users = $stmtUsers->fetchAll(PDO::FETCH_ASSOC);

    // Fetch all posts with user and module details
    $stmtPosts = $pdo->query("
        SELECT posts.id, posts.title, posts.content, posts.created_at, users.name AS user_name, modules.name AS module_name, posts.module_id, posts.user_id
        FROM posts
        LEFT JOIN users ON posts.user_id = users.id
        LEFT JOIN modules ON posts.module_id = modules.id
        ORDER BY posts.created_at DESC
    ");
    $posts = $stmtPosts->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kingdom Come | Manage Posts</title>
    <link rel="stylesheet" href="css/manage_p0sts.css">
</head>
<body>
    <div class="background">
        <div class="container">
            <h1>Manage Posts</h1>

            <!-- Dropdown Filters -->
            <div class="filter-container">
                <!-- Select Module Filter -->
                <div>
                    <label for="module-filter">Filter by Module:</label>
                    <select id="module-filter" class="module-filter">
                        <option value="all">All Modules</option>
                        <?php foreach ($modules as $module): ?>
                            <option value="<?= $module['id']; ?>"><?= htmlspecialchars($module['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Select Author Filter -->
                <div>
                    <label for="author-filter">Filter by Author:</label>
                    <select id="author-filter" class="author-filter">
                        <option value="all">All Authors</option>
                        <?php foreach ($users as $user): ?>
                            <option value="<?= $user['id']; ?>"><?= htmlspecialchars($user['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Add New Post Button -->
                <a href="add_post.php" class="add-button">Add New Post</a>
            </div>

            <!-- Post List -->
            <div id="post-container">
                <?php foreach ($posts as $post): ?>
                    <div id="post-<?= $post['id']; ?>" class="post" data-module="<?= $post['module_id']; ?>" data-user="<?= $post['user_id']; ?>">
                        <h2><?= htmlspecialchars($post['title']) ?></h2>
                        <p><strong>Author:</strong> <?= htmlspecialchars($post['user_name']) ?></p>
                        <p><strong>Module:</strong> <?= htmlspecialchars($post['module_name']) ?></p>
                        <p><strong>Created At:</strong> <?= htmlspecialchars($post['created_at']) ?></p>
                        <p><strong>Content:</strong><br><?= nl2br(htmlspecialchars($post['content'])) ?></p>
                        <a href="edit_post.php?post_id=<?= $post['id'] ?>" class="button">Edit</a>
                        <a href="delete_post.php" class="button" onclick="deletePost(<?= $post['id'] ?>)">Delete</a>
                    </div>
                <?php endforeach; ?>
            </div>

            <div id="no-posts" style="display: none; text-align: center; margin: 20px; color: #47114A; font-weight: bold;">
                No posts found.
            </div>

            <a href="admin_dashboard.php" class="back-home">Back to Admin Dashboard</a>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const moduleFilter = document.getElementById('module-filter');
            const authorFilter = document.getElementById('author-filter');
            const posts = document.querySelectorAll('.post');
            const noPostsMessage = document.getElementById('no-posts');

            moduleFilter.addEventListener('change', filterPosts);
            authorFilter.addEventListener('change', filterPosts);

            function filterPosts() {
                const selectedModule = moduleFilter.value;
                const selectedAuthor = authorFilter.value;
                let found = false;

                posts.forEach(post => {
                    const postModule = post.dataset.module;
                    const postAuthor = post.dataset.user;

                    // Apply filters based on selected module and author
                    if ((selectedModule === 'all' || postModule === selectedModule) && 
                        (selectedAuthor === 'all' || postAuthor === selectedAuthor)) {
                        post.style.display = 'block';
                        found = true;
                    } else {
                        post.style.display = 'none';
                    }
                });

                // If no posts are found after filtering, show the "No posts found" message
                if (found) {
                    noPostsMessage.style.display = 'none';
                } else {
                    noPostsMessage.style.display = 'block';
                }
            }
        });

        function deletePost(postId) {
            if (confirm("Are you sure you want to delete this post?")) {
                fetch(`delete_post.php?post_id=${postId}`, { method: 'GET' })
                    .then(response => response.text())
                    .then(message => {
                        alert(message);
                        if (message.trim() === "Post deleted successfully.") {
                            document.getElementById(`post-${postId}`).remove();
                        }
                    });
            }
        }
    </script>
</body>
</html>
